package iss.java.mail;

import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;


public class MailAuthenticator extends Authenticator{
	private String param;
	private String username;
	private String password;
	private Session session;
	
	public MailAuthenticator(String username,String password){
		this.username=username;
		this.password=password;
	}
	
	 
	public String getParam() {
		return param;
	}
	public void setParam(String param) {
		this.param = param;
	}
	String getUsername() {
		return this.username;
    }
	public String getPassword() {
		return this.password;
	}
	
	//public PasswordAuthentication getPasswordAuthentication() {

	 //   StringTokenizer st = new StringTokenizer(param, ",");
	 //   username = st.nextToken();
	 //   password = st.nextToken();

	  //  return new PasswordAuthentication(username, password);
	 // }
	
	public void ini(String protocolString,String protocol,String host,String hostName){
		Properties props = new Properties();
		// fill props with any information
		props.put(protocolString,protocol);
	    props.put(host, hostName);
		session = Session.getInstance(props, this);
	}
	
	public Session getSession(){
		return this.session;
	}

}
