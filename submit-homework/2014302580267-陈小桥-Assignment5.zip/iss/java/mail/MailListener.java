package iss.java.mail;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;


public class MailListener {
	private MailAuthenticator authenticator;
	private Session session;
	private Folder folder;
	private Message message[]=null;
	
	public MailListener(String pop3HostName) throws MessagingException{
		authenticator=new MailAuthenticator("m15827591729@163.com","cxq119950707");
		authenticator.ini("mail.store.protocol", "pop3","mail.pop3.host", pop3HostName);
		session=authenticator.getSession();
		
		Store store = session.getStore("pop3");
		store.connect("m15827591729@163.com","cxq119950707");
		
		folder = store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		message = folder.getMessages();
	}
	
	public boolean listen() throws MessagingException{
		if(message==null)
		return false;
		return true;
	}
	
	public void receive() throws MessagingException, IOException{
		if(!listen())
			System.out.println("No messages...");
		
		//BufferedReader reader = new BufferedReader (new InputStreamReader(System.in));
		
		for(int i=0;i<message.length;i++){
			Multipart multipart=(Multipart)message[i].getContent();
			
			System.out.println(i+"Message:"+message[i].getSubject());
			System.out.println("From:"+message[i].getFrom().toString());
			
			for (int j=0, n=multipart.getCount(); j<n; j++) {
				  Part part = multipart.getBodyPart(j);
				  String disposition = part.getDisposition();
				  
				  if(disposition == null){
					  System.out.println("\t");
					  message[i].writeTo(System.out);
				  }
				  if ((disposition != null) && (disposition.equals(Part.ATTACHMENT)) || (disposition.equals(Part.INLINE))){ 
					    //saveFile(part.getFileName(), part.getInputStream());
					    File file = new File(part.getFileName());
					    for (int k=0; file.exists(); k++) {
					      file = new File(part.getFileName()+i);
					    }
					    
					    InputStream input=part.getInputStream();
					    OutputStream output=new FileOutputStream(file);
					    
					    byte[] buffer = new byte[part.getSize()]; 
					    int b=0;
					    while (b != -1){  
					    	   b = input.read(buffer);       
					    	   output.write(buffer);  
					    	}  
					    	   input.close();  
					    	   output.close();  
					    	   output.flush(); 

				  }
				  
				  BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
					
					System.out.println("Do you want to delete this massage?Yes or No...");
					String select=reader.readLine();
					if(select.equals("yes")){
						folder.open(Folder.READ_WRITE);
						message[i].setFlag(Flags.Flag.DELETED, true);
					}
			}
			
			
		}
	}
	
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException{
		for(int i=0;i<message.length;i++){
			if(message[i].getSubject().equals(subject))
				return message[i].getContent().toString();
		}
		return "";
	}
	
	
	
}










