package iss.java.mail;

import java.io.IOException;
import java.util.StringTokenizer;

import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;


public class Mail implements IMailService{
	private MailAuthenticator authenticator;
	private MailSender sender;
	private MailListener listener;
	private Session session;
	private String param;
	private String username;
	private String password;
	
	//public Mail(String protocolString,String protocol,String host,String hostName){
		//authenticator.ini(protocolString, protocol, host, hostName);
	//}
	/*
	public PasswordAuthentication getPasswordAuthentication() {

	    StringTokenizer st = new StringTokenizer(param, ",");
	    username = st.nextToken();
	    password = st.nextToken();

	    return new PasswordAuthentication(username, password);
	  }
	  */
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		//authenticator=new MailAuthenticator();
		authenticator=new MailAuthenticator("m15827591729@163.com","cxq119950707");
		//authenticator.getPasswordAuthentication();
		sender=new MailSender("smtp.163.com");
		listener=new MailListener("pop3.163.com");
		//session=authenticator.getSession();
	}

	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
		sender.send(recipient, subject, content);
	}

	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		return listener.listen();
	}

	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		// TODO Auto-generated method stub
		return listener.getReplyMessageContent(sender, subject);
	}

}
