package iss.java.mail;

import java.io.IOException;

import javax.mail.MessagingException;

/**
 * Class that implements interface IMailService
 * 
 * Created by Xiaoqiao_Chen on 2015/11/20.
 * @author Xiaoqiao_Chen
 *
 */
public class Mail2014302580267 implements IMailService{
	/**
	 * A mail authenticator maps on pair of user name and password.
	 */
	private MailAuthenticator2014302580267 mailAuthenticator;
	/**
	 * A mail sender to send mail
	 */
	private MailSender2014302580267 mailSender;
	/**
	 * A mail receiver to receive mail
	 */
	private MailReceiver2014302580267 mailReceiver;
	
	/**
	 * To connect all the mail servers included initial mailAuthenticator,mailSender and mailReceiver.
	 * @throws MessagingException
	 * 						there is any exception of initialization or connection
	 */
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		mailAuthenticator=new MailAuthenticator2014302580267("m15827591729@163.com","nvdhnimofmrpcspm");
		this.mailSender=new MailSender2014302580267(mailAuthenticator,"smtp.163.com");
		this.mailReceiver=new MailReceiver2014302580267(mailAuthenticator,"pop.163.com");
	}
	
	/**
	 * Send mail.
	 * @param recipient
	 * 				the address of receiver
	 * @param subject
	 * 				the subject of the mail
	 * @param content
	 * 				the content of the mail
	 * @throws MessagingException
	 * 						there is any exception of initialization or connection
	 */
	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
		mailSender.send(recipient, subject, content);
		
	}
	
	/**
	 * Ask the mail server whether there are any mails received
	 * @return boolean
	 * 				indicate whether there are any mails received
	 * @throws MessagingException
	 * 						there is any exception of initialization or connection
	 */
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		return mailReceiver.listen();
	}
	
	/**
	 * Receive content of Auto responders and transfer them into String
	 * @param sender
	 * 				the address of mail sender
	 * @param subject
	 * 				the subject of the mail
	 * @return String
	 * 				the String transfered from contend of the mail
	 * @throws MessagingException
	 * 				there is any exception of initialization or connection
	 * @throws IOException
	 * 				there is any exception of downloading the mails
	 */
	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		// TODO Auto-generated method stub
		return mailReceiver.getReplyMessageContent(sender, subject);
	}
	
}
