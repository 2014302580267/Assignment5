package iss.java.mail;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

/**
 * Initialize  mailAuthenticator.
 * 
 * Created by Xiaoqiao_Chen on 2015/11/20.
 * @author Xiaoqiao_Chen
 *
 */
public class MailAuthenticator2014302580267 extends Authenticator{
	/**
	 * The username.
	 */
	private String username;
	/**
	 * The password.
	 */
	private String password;
	/**
	 * The session of mail.
	 */
	private Session session;
	
	/**
	 * Initialize mailSender
	 * @param username
	 * 				the username
	 * @param password
	 * 				the password
	 */
	public MailAuthenticator2014302580267(String username,String password){
		this.username=username;
		this.password=password;
	}
	
	/**
	 * Initialize the session.
	 * @param protocolString
	 * 				the protocol String
	 * @param protocol
	 * 				the name of protocol
	 * @param host
	 * 				the host
	 * @param hostName
	 * 				the name of host
	 */
	public void ini(String protocolString,String protocol,String host,String hostName){
		Properties props = System.getProperties();
		
		// fill props with any information
		props.put(protocolString,protocol);
	    props.put(host, hostName);
		session = Session.getInstance(props, this);
	}
	
	
	public PasswordAuthentication getPasswordAuthentication() {
		return new PasswordAuthentication(username, password);
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}
	
	
}
