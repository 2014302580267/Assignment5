package iss.java.mail;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;

/**
 * Initialize  mailReceiver.
 * 
 * Created by Xiaoqiao_Chen on 2015/11/20.
 * @author Xiaoqiao_Chen
 *
 */
public class MailReceiver2014302580267 {
	/**
	 * Create a mail authenticator.
	 */
	private MailAuthenticator2014302580267 authenticator;
	/**
	 * The mail session
	 */
	private Session session;
	/**
	 * The folder of the store.
	 */
	private Folder folder;
	/**
	 * The mails received.
	 */
	private Message message[]=null;
	
	/**
	 * Initialize MailReceiver.
	 * @param authenticator
	 * 					the mail authenticator
	 * @param pop3HostName
	 * 					the host name of pop3 protocol
	 * @throws MessagingException
	 * 					there is any exception of initialization or connection
	 */
	public MailReceiver2014302580267(MailAuthenticator2014302580267 authenticator,String pop3HostName) throws MessagingException{
		this.authenticator=authenticator;
		this.authenticator.ini("mail.store.protocol", "pop3","mail.pop3.host", pop3HostName);
		this.session=this.authenticator.getSession();
		
		Store store = session.getStore("pop3");
		store.connect(authenticator.getUsername(),authenticator.getPassword());
		
		folder = store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		message = folder.getMessages();
	}
	
	/**
	 * Ask the mail server whether there are any mails received
	 * @return boolean
	 * 				indicate whether there are any mails received
	 * @throws MessagingException
	 * 						there is any exception of initialization or connection
	 */
	public boolean listen() throws MessagingException{
		if(message==null)
		return false;
		return true;
	}
	
	/**
	 * Receive mails.
	 * @throws MessagingException
	 * 				there is any exception of initialization or connection
	 * @throws IOException
	 * 				there is any exception of downloading the mails
	 */
	public void receive() throws MessagingException, IOException{
		if(!listen())
			System.out.println("No messages...");
		
		//BufferedReader reader = new BufferedReader (new InputStreamReader(System.in));
		
		for(int i=0;i<message.length;i++){
			Multipart multipart=(Multipart)message[i].getContent();
			
			System.out.println(i+"Message:"+message[i].getSubject());
			System.out.println("From:"+message[i].getFrom().toString());
			
			for (int j=0, n=multipart.getCount(); j<n; j++) {
				  Part part = multipart.getBodyPart(j);
				  String disposition = part.getDisposition();
				  
				  if(disposition == null){
					  System.out.println("\t");
					  message[i].writeTo(System.out);
				  }
				  if ((disposition != null) && (disposition.equals(Part.ATTACHMENT)) || (disposition.equals(Part.INLINE))){ 
					    //saveFile(part.getFileName(), part.getInputStream());
					    File file = new File(part.getFileName());
					    for (int k=0; file.exists(); k++) {
					      file = new File(part.getFileName()+k);
					    }
					    
					    InputStream input=part.getInputStream();
					    OutputStream output=new FileOutputStream(file);
					    
					    byte[] buffer = new byte[part.getSize()]; 
					    int b=0;
					    while (b != -1){  
					    	   b = input.read(buffer);       
					    	   output.write(buffer);  
					    	}  
					    	   input.close();  
					    	   output.close();  
					    	   output.flush(); 

				  }
				  
				  BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
					
					System.out.println("Do you want to delete this massage?Yes or No...");
					String select=reader.readLine();
					if(select.equals("yes")){
						folder.open(Folder.READ_WRITE);
						message[i].setFlag(Flags.Flag.DELETED, true);
					}
			}
			
			
		}
	}
	
	/**
	 * Receive content of Auto responders and transfer them into String
	 * @param sender
	 * 				the address of mail sender
	 * @param subject
	 * 				the subject of the mail
	 * @return String
	 * 				the String transfered from contend of the mail
	 * @throws MessagingException
	 * 				there is any exception of initialization or connection
	 * @throws IOException
	 * 				there is any exception of downloading the mails
	 */
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException{
		for(int i=0;i<message.length;i++){
			if(message[i].getSubject().equals(subject))
				return message[i].getContent().toString();
		}
		return "";
	}
}
